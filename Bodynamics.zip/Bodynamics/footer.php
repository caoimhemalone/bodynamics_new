<!-- Footer -->
	    <footer class="bg-dark" alt="footer">
	      <div class="container">
	      	<div class="social-bar row py-5 bg-dark">
	      		<ul>
					<li><a href="https://www.instagram.com/bodynamicsfitness" target="_blank" alt="instagram link"><img src="images/icons/instagram.png" alt="instagram image"></a></li>
					<li> <a href="https://www.facebook.com/bodynamicsfitness" target="_blank"> <img src="images/icons/fb.png" alt="facebook link" alt="facebook image"></a></li>
					<li><a href="mailto:colm.bodynamics@gmail.com" alt="email link"> <img alt="email image"src="images/icons/email.png"></a></li>
				</ul>
			</div>
	        <p class="m-0 text-center text-white">Copyright &copy; Bodynamics 2019</p>
	        <p class="m-0 text-center text-white">Web Development & Design by key-vah</p>
	         <p class="m-0 text-center text-white icon-footer">Icons made by <a href="https://www.flaticon.com/authors/monkik" target="_blank" title="monkik">monkik</a> from <a href="https://www.flaticon.com/" 		    title="Flaticon" target="_blank">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 		    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></p>

	      </div>
	    </footer>
   <!-- < ?php wp_footer(); ?> -->
  </body>
</html>
